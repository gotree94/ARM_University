#include  															// 0 for increasing brightness, 1 for decreasing brightness


void systick_callback_isr(void) {
	

}


int main(void) {
	


	while(1) 
	{

	}
}
