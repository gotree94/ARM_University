# Internet-of-Things-Education-Kit

## Important
### To download the latest stable version, please click below instead of using the "Download ZIP" button.
### [Click here to download](https://github.com/arm-university/Internet-of-Things-Education-Kit/releases/download/v2.0.0/Internet-of-Things-Education-Kit.zip)

## About

Welcome to our Internet of Things Education Kit!

Our flagship offering to universities worldwide is the Arm University Program Education Kit series.

These self-contained educational materials offered exclusively and at no cost to academics and teaching staff worldwide. They’re designed to support your day-to-day teaching on core electronic engineering and computer science subjects. You have the freedom to choose which modules to teach – you can use all the modules in the Education Kit or only those that are most appropriate to your teaching outcomes.

Our Internet of Things Education Kit covers the  fundamental concepts of the Internet of Things (IoT), such as embedded systems, connectivity, cloud computing, and security. The Education Kit provides student with practical experience in creating smartphone apps and controlling a wearable device using the Arm Mbed platform and Android SDK. This kit focuses on the transformative intersection between the internet, mobile and sensor technology and providing the skill set to get involved in IoT development. A full description of the education kit can be found [here](https://www.arm.com/resources/education/education-kits/internet-of-things).

## Mbed Announcement

Arm has announced the End of Life Timeline for Mbed. The Arm Education team is actively working on creating alternative teaching and learning solutions in time for the new academic terms starting Fall/Autumn 2025. We welcome feedback from the academic community on this. Reach out to the team at: education@arm.com


 ## Kit specification:

* A full set of lecture slides, ready for use in a typical 10-12-week undergraduate course (full syllabus below).
* Lab manuals with solutions for faculty. Labs use low cost, powerful hardware boards. Lab code and assets can be found [here](https://community.arm.com/aup/iot-st/).
* **Prerequisites:** Basics of programming in C/ C++, entry level Java programming.

## Course Aim
To produce students who can specify, design, and program modern connected electronic systems in response to the ever-growing number of connected devices.

## Syllabus
1. Introduction to the Internet of Things
1. IoT System Architectures and Standards 
1. Introduction to Embedded Systems
1. Hardware Platforms for IoT
1. The Arm Cortex-M4 Processor Architecture
1. Interrupts and Low Power Features
1. Introduction to the Mbed Platform and CMSIS
1. IoT Connectivity Part I 
1. IoT Connectivity Part II
1. The Cloud
1. IoT Security
1. Current and Future IoT Trends

## License
You are free to fork or clone this material. See [LICENSE.md](https://github.com/arm-university/Internet-of-Things-Education-Kit/blob/main/License/LICENSE.md) for the complete license.

## Inclusive Language Commitment
Arm is committed to making the language we use inclusive, meaningful, and respectful. Our goal is to remove and replace non-inclusive language from our vocabulary to reflect our values and represent our global ecosystem.
 
Arm is working actively with our partners, standards bodies, and the wider ecosystem to adopt a consistent approach to the use of inclusive language and to eradicate and replace offensive terms. We recognise that this will take time. This course has been updated to replace references to non-inclusive language. We recognise that some of you will be accustomed to using the previous terms and may not immediately recognise their replacements. Please refer to the following example:

•	When introducing the AMBA AHB Protocols, we will use the term ‘Manager’ instead of ‘Master’ and ‘Subordinate’ instead of ‘Slave’. 

This course may still contain other references to non-inclusive language; it will be updated with newer terms as those terms are agreed and ratified with the wider community.

Contact us at education@arm.com with questions or comments about this course. You can also report non-inclusive and offensive terminology usage in Arm content at terms@arm.com.

## Attribution
The dataset provided in the lab resources can be found here: https://www.kaggle.com/vmalyi/run-or-walk – This dataset was created by Viktor Malyi under the CC BY-NC-SA 4.0 license https://creativecommons.org/licenses/by-nc-sa/4.0/
