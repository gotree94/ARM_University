$(document).foundation()

//$(document).bind("contextmenu",function(){ return false; });

var AupCourse = angular.module('AupCourse', [
	'AupControllers'
]);