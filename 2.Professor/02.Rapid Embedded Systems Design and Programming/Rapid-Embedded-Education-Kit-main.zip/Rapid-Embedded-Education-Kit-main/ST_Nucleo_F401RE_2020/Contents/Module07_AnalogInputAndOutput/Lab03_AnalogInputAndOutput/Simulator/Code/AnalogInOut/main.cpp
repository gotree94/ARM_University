/*----------------------------------------------------------------------------
LAB EXERCISE 3 - Analog input and PWM
 ----------------------------------------
	Use two potentiometers to adjust the volume and pitch of the output sound wave.
	
	Inputs: potentiometers 1 and 2
	Output: speaker, PC

	GOOD LUCK!
 *----------------------------------------------------------------------------*/

#include "mbed.h"


/*
Define the PWM speaker output
Define analog inputs
*/

	//Write your code here


//Define variables
float i;

/*----------------------------------------------------------------------------
 MAIN function
 *----------------------------------------------------------------------------*/

int main(){
	while(1){
		/*
		Create a saw-tooth sound wave
		Make the period and volume adjustable using the potentiometers
		*/
	}
}

// *******************************ARM University Program Copyright © ARM Ltd 2019*************************************
