#include "mbed.h"

// Serial tx, rx connected to the PC via an USB cable
Serial device(p13, p14);

/*----------------------------------------------------------------------------
 MAIN function
 *----------------------------------------------------------------------------*/

int main(){
	/*
  Set the baudrate to 9600 bps
  Print "Hello mbed" to the PC serial monitor
  */
    //Write your code here
}