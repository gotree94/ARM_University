## Desired Contributions

Below is a short list of the areas we are looking for contributions:
- Converting lab documents from 'Word' documents to GitHub markdown.
- Update Mbed OS content in lecture slides from Mbed OS 5 to Mbed OS 6.
- Test lab documents and correct any errors/provide improvements.
